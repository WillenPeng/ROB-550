#!/usr/bin/env bash
# NOTE: only used if using lcm-spy
# run: source setenv.sh or . setenv.sh
export CLASSPATH=$CLASSPATH:$PWD/java/lcmtypes.jar
