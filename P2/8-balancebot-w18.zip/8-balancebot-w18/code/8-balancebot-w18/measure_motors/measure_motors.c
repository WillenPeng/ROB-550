/*******************************************************************************
* measure_motors.c
*
* 
*******************************************************************************/
#include "../balancebot/balancebot.h"

FILE * f1;

void* data_loop(void* ptr){
	//f1 = fopen("motor2.dat", "w");
	while(1){
	//TODO: take your data here
		uint64_t currenttime = rc_nanos_since_boot();
		int new_encoder_pos_l = rc_get_encoder_pos(1);
		int new_encoder_pos_r = rc_get_encoder_pos(2);
		float curr_l = rc_adc_volt(0)/0.5;
		float curr_r = rc_adc_volt(1)/0.5;
		// double rotation_speed_l = (new_encoder_pos_l - old_encoder_pos_l)*2*3.14159/GEAR_RATIO/ENCODER_RES;
		// double rotation_speed_r= (new_encoder_pos_r - old_encoder_pos_r)*2*3.14159/GEAR_RATIO/ENCODER_RES;
		fprintf(f1, "%d %d %lld %f %f\n", new_encoder_pos_l, new_encoder_pos_r, currenttime, curr_l, curr_r);
		rc_nanosleep(1E7);
	}
}

/*******************************************************************************
* int main() 
*
*******************************************************************************/
int main(){
	// always initialize cape library first
	if(rc_initialize()){
		fprintf(stderr,"ERROR: failed to initialize rc_initialize(), are you root?\n");
		return -1;
	}
	f1 = fopen("../motor_1_0.dat", "w");
	//set cpu freq to max performance
	rc_set_cpu_freq(FREQ_1000MHZ);

	// start data thread to take data
	printf("starting data thread... \n");
	pthread_t  data_thread;
	pthread_create(&data_thread, NULL, data_loop, (void*) NULL);

	// done initializing so set state to RUNNING
	mb_initialize_motors();
	rc_set_encoder_pos(1, 0);
	rc_set_encoder_pos(2, 0);

	rc_set_state(RUNNING);

	//TODO: run your motor tests here while the data thread takes data
	mb_set_motor(RIGHT_MOTOR, 1.0);
	mb_set_motor(LEFT_MOTOR, 1.0);
	rc_nanosleep(15E9);

	rc_set_state(EXITING);	

	// exit cleanly
	mb_disable_motors();
	rc_cleanup();
	fclose(f1);
	
	 
	return 0;
}