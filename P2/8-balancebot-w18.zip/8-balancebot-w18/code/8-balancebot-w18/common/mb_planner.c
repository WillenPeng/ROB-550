#include "mb_planner.h"

void position_control(PathPlanner *planner, mb_state_t* state, mb_odometry_t* odometry){
    float error_x_dist, error_y_dist;
    if (mission_num == 1){
        error_x_dist = planner->Square_goal_x[3] - odometry->x;
        error_y_dist = planner->Square_goal_y[3] - odometry->y;
    }
    if (mission_num == 2){
        error_x_dist = planner->Straight_goal_x - odometry->x;
        error_y_dist = planner->Straight_goal_y - odometry->y;
    }
    if (mission_num == 3){
        error_x_dist = planner->Auto_goal_x[WayPtsNum-1] - odometry->x;
        error_y_dist = planner->Auto_goal_y[WayPtsNum-1] - odometry->y;
    }
    float thetaToGoal = atan2(error_y_dist, error_x_dist);
    float distance = sqrt(error_x_dist * error_x_dist + error_y_dist * error_y_dist);
    float d_theta;
    // if (mission_num == 3){
    //     d_theta = -(thetaToGoal - state->opti_theta);
    // }
    // else{
    d_theta = -(thetaToGoal - odometry->theta);
    // }
    // printf("d_theta: %f\n", d_theta);
    if (fabs(d_theta) > PI/2 && fabs(d_theta) < 3.0/2.0*PI){
        distance *= -1;
    }

    state->desired_fwd_v = 0.0; //PID_Compute(planner->pid_lin, distance);
    state->desired_turn_v = 0.0;
}

int mb_planner_compute_speed(PathPlanner *planner, mb_state_t* state, mb_odometry_t* odometry){
    float error_x_dist = 0.0;
    float error_y_dist = 0.0;
    float d_theta;
    if (planner->current_mission == STRAIGHT){
        error_x_dist = planner->Straight_goal_x - odometry->x;
        error_y_dist = planner->Straight_goal_y - odometry->y;
    }
    if (planner->current_mission == SQUARE){
        error_x_dist = planner->Square_goal_x[planner->Square_current_pos] - odometry->x;
        error_y_dist = planner->Square_goal_y[planner->Square_current_pos] - odometry->y;
    }
    if (planner->current_mission == AUTONOMOUS){
        error_x_dist = planner->Auto_goal_x[planner->Auto_current_pos] - odometry->x;
        error_y_dist = planner->Auto_goal_y[planner->Auto_current_pos] - odometry->y;
    }
    float thetaToGoal = atan2(error_y_dist, error_x_dist);
    float distance = sqrt(error_x_dist * error_x_dist + error_y_dist * error_y_dist);
    // if (thetaToGoal < PI/4 || thetaToGoal > -PI/4 || thetaToGoal > 3*PI/4 || thetaToGoal < -3*PI/4){
    //     distance = error_y_dist;
    // }
    // else{
    //     distance = error_x_dist;
    // }
    
    d_theta = -(thetaToGoal - odometry->theta);
    if (fabs(d_theta) > PI){
        if (thetaToGoal > 0){
            thetaToGoal = PI - thetaToGoal;
        }
        else{
            thetaToGoal = -PI - thetaToGoal;
        }
        float newtheta;
        if (odometry->theta > 0){
            newtheta = PI - odometry->theta;
        }
        else{
            newtheta = -PI - odometry->theta;
        }
        d_theta = (thetaToGoal - newtheta);
    }
    // STRAIGHT Mission
    printf("%f   %f\n", d_theta, thetaToGoal);
    printf("RT_state: %d\n", (int)planner->RT_state);
    if (planner->RT_state == TRANSLATE){
        if (goal_reach(distance, d_theta, TRANSLATE, planner)){
            state->desired_fwd_v = 0.0;
            state->desired_turn_v = 0.0;
            return 1;
        }
        else{
            if (planner->current_mission == AUTONOMOUS){
                state->desired_fwd_v = 0.65;
                // state->desired_fwd_v = PID_Compute(planner->pid_lin, 2.9*distance);
            }
            else{
                state->desired_fwd_v = PID_Compute(planner->pid_lin, distance);
                // state->desired_fwd_v = 0.0;
            }
            state->desired_turn_v = PID_Compute(planner->pid_rot, d_theta);
            // state->desired_turn_v = 0.0;
            return 0;
            // }
        }
    }
    else{
        if (goal_reach(distance, d_theta, ROTATE, planner)){
            state->desired_fwd_v = 0.0;
            state->desired_turn_v = 0.0;
            return 1;
        }
        else{
            state->desired_fwd_v = 0.0;
            state->desired_turn_v = PID_Compute(planner->pid_rot, d_theta);
            // state->desired_turn_v = 0.0;
            return 0;
        }
    }
}

int goal_reach(float distance, float d_theta, RTR_State RT_state, PathPlanner *planner){
    if (planner->current_mission == AUTONOMOUS){
        if (RT_state == TRANSLATE){
            if (distance < 0.1){
                printf("REACH GOAL(distance), Error theta: %f, distance: %f, rotateortranslate: %d\n", d_theta, distance, RT_state);
                return 1;
            }
            else{
                return 0;
            }
        }
        else{
            if (fabs(d_theta) < 0.12){
                printf("REACH GOAL(d_theta), Error theta: %f, distance: %f, rotateortranslate: %d\n", d_theta, distance, RT_state);
                return 1;
            }
            else{
                return 0;
            }
        }
    }
    else{
        if (RT_state == TRANSLATE){
            if (distance < 0.2){
                printf("REACH GOAL(distance), Error theta: %f, distance: %f, rotateortranslate: %d\n", d_theta, distance, RT_state);
                return 1;
            }
            else{
                return 0;
            }
        }
        else{
            if (fabs(d_theta) < 0.1){
                printf("REACH GOAL(d_theta), Error theta: %f, distance: %f, rotateortranslate: %d\n", d_theta, distance, RT_state);
                return 1;
            }
            else{
                return 0;
            }
        } 
    }
    
}

void mb_load_planner_pid_config(PathPlanner *Newplanner){
    FILE* file = fopen(CFG_PLANNER, "r");
    if (file == NULL){
        printf("Error opening pid_planner.cfg\n");
    }

    pid_parameters_t lin_pid_params;
    pid_parameters_t rot_pid_params;
    
    fscanf(file, "%f %f %f %f",
        &lin_pid_params.kp,
        &lin_pid_params.ki,
        &lin_pid_params.kd,
        &lin_pid_params.dFilterHz
        );

    fscanf(file, "%f %f %f %f",
        &rot_pid_params.kp,
        &rot_pid_params.ki,
        &rot_pid_params.kd,
        &rot_pid_params.dFilterHz
        );

    fscanf(file, "%f %f %f %f %f %f %f %f",
        &Newplanner->Square_goal_x[0],
        &Newplanner->Square_goal_y[0],
        &Newplanner->Square_goal_x[1],
        &Newplanner->Square_goal_y[1],
        &Newplanner->Square_goal_x[2],
        &Newplanner->Square_goal_y[2],
        &Newplanner->Square_goal_x[3],
        &Newplanner->Square_goal_y[3]
        );

    fscanf(file, "%f %f",
        &Newplanner->Straight_goal_x,
        &Newplanner->Straight_goal_y
        );

    fscanf(file, "%d",
        &mission_num
        );

    float fwd_straight, turn_straight;
    fscanf(file, "%f %f",
        &fwd_straight,
        &turn_straight
        );

    float fwd_square, turn_square;
    fscanf(file, "%f %f",
        &fwd_square,
        &turn_square
        );

    float fwd_auto, turn_auto;
    fscanf(file, "%f %f",
        &fwd_auto,
        &turn_auto
        );

    Newplanner->current_mission = mission_num;

    fclose(file);

    Newplanner->Square_current_pos = 0;
    Newplanner->Auto_current_pos = 0;
    Newplanner->RT_state = TRANSLATE;

    Newplanner->pid_lin = PID_Init(
            lin_pid_params.kp,
            lin_pid_params.ki,
            lin_pid_params.kd,
            lin_pid_params.dFilterHz,
            SAMPLE_RATE_HZ
            );

    Newplanner->pid_rot = PID_Init(
            rot_pid_params.kp,
            rot_pid_params.ki,
            rot_pid_params.kd,
            rot_pid_params.dFilterHz,
            SAMPLE_RATE_HZ
            );

    float FWD_VEL_MAX, TURN_VEL_MAX;
    if (Newplanner->current_mission == SQUARE){
        FWD_VEL_MAX = fwd_square;
        TURN_VEL_MAX = turn_square;
    }
    if (Newplanner->current_mission == STRAIGHT){
        FWD_VEL_MAX = fwd_straight;
        TURN_VEL_MAX = turn_straight;
    }
    if (Newplanner->current_mission == AUTONOMOUS){
        FWD_VEL_MAX = fwd_auto;
        TURN_VEL_MAX = turn_auto;
    }

    PID_SetOutputLimits(Newplanner->pid_lin, -FWD_VEL_MAX, FWD_VEL_MAX);
    PID_SetIntegralLimits(Newplanner->pid_lin, -FWD_VEL_MAX, FWD_VEL_MAX);
    PID_SetOutputLimits(Newplanner->pid_rot, -TURN_VEL_MAX, TURN_VEL_MAX);
    PID_SetIntegralLimits(Newplanner->pid_rot, -TURN_VEL_MAX, TURN_VEL_MAX);

}

PathPlanner* planner_init(){
    PathPlanner *Newplanner = (PathPlanner*) malloc(sizeof(PathPlanner));
    mb_load_planner_pid_config(Newplanner);
    return Newplanner;
}