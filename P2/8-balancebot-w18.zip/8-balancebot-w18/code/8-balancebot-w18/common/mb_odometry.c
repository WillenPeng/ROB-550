/*******************************************************************************
* mb_odometry.c
*
* TODO: Implement these functions to add odometry and dead rekoning 
*
*******************************************************************************/

#include "../balancebot/balancebot.h"
#include <math.h>

#define DTHETA_THRESH 0.001
#define ticks2meter 60/GEAR_RATIO/ENCODER_RES*2.0*PI*WHEEL_DIAMETER/2/60 // see Note for this const

void mb_initialize_odometry(mb_odometry_t* mb_odometry, float x, float y, float theta){
    mb_odometry->x = x;
    mb_odometry->y = y;
    mb_odometry->theta = theta;
}

void mb_update_odometry(mb_odometry_t* mb_odometry, mb_state_t* mb_state){
    // encoder is set to zero everytime it gets updated
    // see void balancebot_controller() in balancebot.c 
    float dl = mb_state->left_encoder * ticks2meter;
    float dr = mb_state->right_encoder * ticks2meter;
    float b =  WHEEL_BASE;       // wheel separation distance in meters, mb_defs.h
    
    // update params based on odometry model
    float d_theta = (dr - dl) / b;
    float d_x = (dr + dl) / 2;
    // float d_y = 0;    // no side slip

    // compound operation
    float theta = mb_odometry->theta;
    mb_odometry->x = mb_odometry->x + d_x*cos(theta);
    mb_odometry->y = mb_odometry->y + d_x*sin(theta);
    mb_odometry->theta += d_theta;

    mb_odometry->theta = mb_clamp_radians(mb_odometry->theta);
}


float mb_clamp_radians(float angle){
	if(angle < -PI) {
		angle += 2*PI;
	}

	if(angle > PI) {
		angle -= 2*PI;
	}
    return angle;
}


