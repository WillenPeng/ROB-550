#ifndef MB_PLANNER_H
#define MB_PLANNER_H

#include <rc_usefulincludes.h> 
#include <roboticscape.h>
#include "mb_defs.h"
#include "mb_structs.h"
#include "mb_pid.h"
#include <stdlib.h>
#include <math.h>

#define CFG_PLANNER "pid_planner.cfg"

typedef enum RTR_State{
    TRANSLATE,
    ROTATE
} RTR_State;

typedef enum mission_state {
    BALANCE,
    SQUARE,
    STRAIGHT,
    AUTONOMOUS
} mission_state;

typedef struct PathPlanner{
    PID_t * pid_lin;
    PID_t * pid_rot;

    float Square_goal_x[4];
    float Square_goal_y[4];
    int Square_current_pos;

    float Straight_goal_x;
    float Straight_goal_y;

    float Auto_goal_x[100];
    float Auto_goal_y[100];
    int Auto_current_pos;

    RTR_State RT_state;

    mission_state current_mission;

} PathPlanner;

int mission_num;
int WayPtsNum;
int dist_flag;

void mb_load_planner_pid_config(PathPlanner *Newplanner);
int mb_planner_compute_speed(PathPlanner *planner, mb_state_t* state,
        mb_odometry_t* odometry);
int goal_reach(float distance, float d_theta, RTR_State RT_state, PathPlanner *planner);

void position_control(PathPlanner *planner, mb_state_t* state, mb_odometry_t* odometry);

PathPlanner* planner_init();



#endif