/*******************************************************************************
* mb_pid.c
*
* TODO: implement these functions to build a generic PID controller
*       with a derivative term low pass filter
*
*******************************************************************************/

#include "mb_pid.h"

#define MAX_OUTPUT 1.0
#define MIN_OUTPUT -1.0
#define ITERM_MIN -1.0
#define ITERM_MAX 1.0

PID_t * PID_Init(float Kp, float Ki, float Kd, float dFilterHz, float updateHz) {
  // zero initial values
  PID_t *pid =  malloc(sizeof(PID_t));
  PID_SetTunings(pid, Kp, Ki, Kd);
  pid->pidInput = 0.0;
  pid->pidOutput = 0.0;
  pid->pTerm = 0.0;
  pid->iTerm = 0.0;
  pid->dTerm = 0.0;
  pid->prevInput = 0.0;
  pid->Iterm_count = 0;
  PID_SetIntegralLimits(pid, ITERM_MIN, ITERM_MAX);
  PID_SetOutputLimits(pid, MIN_OUTPUT, MAX_OUTPUT);
  pid->dFilter = rc_empty_filter();
  rc_butterworth_lowpass(&(pid->dFilter), 2, 1.0/updateHz, 2.0*PI*dFilterHz);
  PID_SetDerivativeFilter(pid, dFilterHz);
  PID_SetUpdateRate(pid, updateHz);
  return pid;
}

float PID_Compute(PID_t* pid, float error) { 
  pid->pidInput = error;
  pid->pTerm = pid->kp * error;
  //if (pid->Iterm_count == 1000){
  //  pid->iTerm = 0;
  //  pid->Iterm_count = 0;
  //}
  //else{
  pid->iTerm = pid->iTerm + pid->ki*error/pid->updateHz;
  if(pid->iTerm >= pid->iTermMax){
    pid->iTerm = pid->iTermMax;
  }
  else if(pid->iTerm <= pid->iTermMin){
    pid->iTerm = pid->iTermMin;
  }
    //pid->Iterm_count++;
  //}
  pid->dTerm = pid->kd * (pid->pidInput - pid->prevInput) * pid->updateHz;
  pid->dTerm = rc_march_filter(&(pid->dFilter), pid->dTerm);
  pid->pidOutput = pid->pTerm + pid->iTerm + pid->dTerm;
  pid->prevInput = pid->pidInput;
  if(pid->pidOutput >= pid->outputMax){
  	pid->pidOutput = pid->outputMax;
  }
  else if(pid->pidOutput <= pid->outputMin){
  	pid->pidOutput = pid->outputMin;
  }
  return pid->pidOutput;
}

void PID_SetTunings(PID_t* pid, float Kp, float Ki, float Kd) {
  //scale gains by update rate in seconds for proper units
	pid->kp = Kp;
	pid->ki = Ki;
	pid->kd = Kd;
	return;
}

void PID_SetOutputLimits(PID_t* pid, float min, float max){
	pid->outputMin = min;
	pid->outputMax = max;
	return;
}

void PID_SetIntegralLimits(PID_t* pid, float min, float max){
	pid->iTermMin = min;
	pid->iTermMax = max;
	return;
}

void PID_ResetIntegrator(PID_t* pid){
	pid->iTerm = 0;
	return;
}

void PID_SetDerivativeFilter(PID_t* pid, float dFilterHz){
	pid->dFilterHz = dFilterHz;
	return;
}

void PID_SetUpdateRate(PID_t* pid, float updateHz){
	pid->updateHz = updateHz;
	return;
}
