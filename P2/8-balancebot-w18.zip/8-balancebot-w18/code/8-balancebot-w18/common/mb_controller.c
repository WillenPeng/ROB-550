#include "mb_controller.h"

/*******************************************************************************
* int mb_initialize()
*
* this initializes all the PID controllers from the configuration file
* you can use this as is or modify it if you want a different format
*
* return 0 on success
*
*******************************************************************************/
int mb_initialize_controller(){

    mb_load_controller_config();
    
    //TODO: initialize your controller here
    int updateHz = 100;  
    pidSpeed = PID_Init(speed_pid_params.kp,speed_pid_params.ki,speed_pid_params.kd,speed_pid_params.dFilterHz,updateHz);
    pidTilt = PID_Init(tilt_pid_params.kp,tilt_pid_params.ki,tilt_pid_params.kd,tilt_pid_params.dFilterHz,updateHz);
    pidTurn = PID_Init(turn_pid_params.kp,turn_pid_params.ki,turn_pid_params.kd,turn_pid_params.dFilterHz,updateHz);
    // pidLeftMotor = PID_Init(left_pid_params.kp,left_pid_params.ki,left_pid_params.kd,left_pid_params.dFilterHz,updateHz);
    // pidRightMotor = PID_Init(right_pid_params.kp,right_pid_params.ki,right_pid_params.kd,right_pid_params.dFilterHz,updateHz);
    
    // Speeed limit
    PID_SetOutputLimits(pidSpeed,-0.2,0.2);
    PID_SetIntegralLimits(pidSpeed,-0.2,0.2);
    // Tilt limit
    PID_SetOutputLimits(pidTilt,-1,1);
    PID_SetIntegralLimits(pidTilt,-1,1);
    // Turn limit
    PID_SetOutputLimits(pidTurn,-1,1);
    PID_SetIntegralLimits(pidTurn,-1,1);

    low_pass = rc_empty_filter();
    rc_first_order_lowpass(&low_pass, 0.01, 0.2);

    // Motor limit
    // PID_SetOutputLimits(pidLeftMotor,-1,1);
    // PID_SetIntegralLimits(pidLeftMotor,-1,1);
    // PID_SetOutputLimits(pidRightMotor,-1,1);
    // PID_SetIntegralLimits(pidRightMotor,-1,1);
      
    
    return 0;
}

/*******************************************************************************
* int mb_load_controller_config()
*
* this provides a basic configuration load routine
* you can use this as is or modify it if you want a different format
*
* return 0 on success
*
*******************************************************************************/


int mb_load_controller_config(){
    FILE* file = fopen(CFG_PATH, "r");
    if (file == NULL){
        printf("Error opening pid.cfg\n");
    }

    //TODO: You can add to or modify the cfg file as you like
    // This is here as an example

    fscanf(file, "%f %f %f %f", 
        &left_pid_params.kp,
        &left_pid_params.ki,
        &left_pid_params.kd,
        &left_pid_params.dFilterHz
        );

    fscanf(file, "%f %f %f %f",
        &right_pid_params.kp,
        &right_pid_params.ki,
        &right_pid_params.kd,
        &right_pid_params.dFilterHz
        );

    fscanf(file, "%f %f %f %f",
        &speed_pid_params.kp,
        &speed_pid_params.ki,
        &speed_pid_params.kd,
        &speed_pid_params.dFilterHz
        );

    fscanf(file, "%f %f %f %f",
        &tilt_pid_params.kp,
        &tilt_pid_params.ki,
        &tilt_pid_params.kd,
        &tilt_pid_params.dFilterHz
        );

    fscanf(file, "%f %f %f %f",
        &turn_pid_params.kp,
        &turn_pid_params.ki,
        &turn_pid_params.kd,
        &turn_pid_params.dFilterHz
        );

    fclose(file);
    return 0;
}

/*******************************************************************************
* int mb_controller_update()
* 
* TODO: Write your cascaded PID controller here
* take inputs from the global mb_state
* write outputs to the global mb_state
*
* return 0 on success
*
*******************************************************************************/

int mb_controller_update(mb_state_t* mb_state){
    //TODO: update your controller each timestep, called by 

    // set forward speed and turning speed
    // mb_state->desired_fwd_v = left_pid_params.kp;
    // printf("%f   %f\n",mb_state->desired_fwd_v,mb_state->desired_turn_v);
    // controller
    float leftSpeed = encoder_to_RPM(mb_state->left_encoder);
    float rightSpeed = encoder_to_RPM(mb_state->right_encoder);
    float avgSpeed = (leftSpeed+rightSpeed)/2.0 * 2.0*PI*WHEEL_DIAMETER/2/60;
    
    float avgSpeed_new = rc_march_filter(&(low_pass), avgSpeed);
    // printf("%f   %f\n",avgSpeed_new,avgSpeed);
    // speed controller
    mb_state->speedError = mb_state->desired_fwd_v - avgSpeed_new;
    float desireTilt = PID_Compute(pidSpeed,mb_state->speedError) + mb_state->desireTiltOffset;

    // printf(" %f\n",avgSpeed_new);
    // tilt controller
    mb_state->speedPTerm = pidSpeed->pTerm;
    mb_state->speedITerm = pidSpeed->iTerm;
    mb_state->speedDTerm = pidSpeed->dTerm;
    mb_state->alphaError = (desireTilt-0.0085) - mb_state->alpha;
    float cmdSpeed = PID_Compute(pidTilt,mb_state->alphaError);
    mb_state->tiltPTerm = pidTilt->pTerm;
    mb_state->tiltITerm = desireTilt- mb_state->desireTiltOffset;
    mb_state->tiltDTerm = pidTilt->dTerm;
    // turning controller
    float turnSpeed = (rightSpeed - leftSpeed)* 2.0*PI *WHEEL_DIAMETER/60.0/WHEEL_BASE;
    float turnError = mb_state->desired_turn_v - turnSpeed;
    float turn_pwm = PID_Compute(pidTurn,turnError);
    // printf("%f    %f\n", desireTilt, mb_state->alpha);
    mb_state->turnError = turnError;
    mb_state->rightError = turn_pwm;
    //printf("%f   %f\n", cmdSpeed, leftSpeed);
    if (turn_pwm > 0){
        mb_state->left_cmd = cmdSpeed - turn_pwm;
        mb_state->right_cmd = cmdSpeed + turn_pwm;
    }
    else{
        mb_state->left_cmd = cmdSpeed - turn_pwm;
        mb_state->right_cmd = cmdSpeed + turn_pwm;
    }

    // mb_state->left_cmd = 0;
    // mb_state->right_cmd = 0;

    return 0;
}

float encoder_to_RPM(float encoder){
    return (encoder*SAMPLE_RATE_HZ*60/GEAR_RATIO/ENCODER_RES);
}
/******************************************************************{
************
* int mb_destroy_controller()
* 
* TODO: Free all resources associated with your controller
*
* return 0 on success
*
*******************************************************************************/

int mb_destroy_controller(){
    //TODO: free the memory for your controller if needed
    return 0;
}
